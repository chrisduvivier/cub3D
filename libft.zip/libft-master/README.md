# libft
The C library which will be updated as I complete the projects of 42 school.

# Branches
- master
- init_version: This one keeps the original version which passed the moulinette.
